#include<stdio.h>
#include<stdlib.h>

struct node{
	int num;
	struct node* next;
};
typedef struct node node;

int compare(char str1[], char str2[]);
void printList(struct node*);
void freeList(node*);
void pop(node**);
void enqueue(node**, int);
void push(node**, int);

int stacksize = 0;

int main(int argc, char* argv[argc+1]){

	//first read string
	//if its not pop, keep reading line

	if(argc != 2){
		printf("error\n");
		return EXIT_SUCCESS;
	}

	FILE *f = fopen(argv[1], "r");
	char str[20];
	int i;
	node* head = NULL;

	while(fscanf(f, " %s", &str[0]) != EOF){
		char enq[8] = "ENQUEUE";
		char pu[5] = "PUSH";
		char po[4] = "POP";
		if(compare(str, enq) == 1){
			fscanf(f, "%d\n", &i);
			enqueue(&head, i);
			printList(head);
		}
		else if(compare(str, pu) == 1){
			fscanf(f, "%d\n", &i);
			push(&head, i);
			printList(head);
		}
		else if(compare(str, po) == 1){
		  if(stacksize != 0){
		        pop(&head);
			if (head != 0){
				printList(head);
			}
			else{
				printf("EMPTY\n");
			}
		  }
		  else{
		    printf("EMPTY\n");
		  }
		}
		else{
			printf("error");
		}
	}

	freeList(head);

	fclose(f);

	return EXIT_SUCCESS;
}

/* removes head node */
void pop(node** head){
	if(head == 0){
		return;
	}
	node* temp = *head;
	*head = temp->next;
	free(temp);
	stacksize--;
}

/* adds number to front of list */
void push(node** head, int i){
	node* newn = (node *)malloc(sizeof(node));
	newn->num = i;
	newn->next = 0;

	/* linked list is empty */
	if(*head == 0){
		*head = newn;
		stacksize++;
		return;
	}
	/* if new node needs to be inserted at front */
	else{
		newn->next = *head;
		*head = newn;
	}
	stacksize++;
}

/* adds number to end of list */
void enqueue(node** head, int i){
	node* newn = (node *)malloc(sizeof(node));
	newn->num = i;
	newn->next = 0;

	/* linked list is empty */
	if(*head == 0){
		*head = newn;
		stacksize++;
		return;
	}
	/* loop to end and add new node */
	else{
		node* curr = *head;
		while((curr->next != 0)){
			curr = curr->next;
		}
		newn->next = curr->next;
		curr->next = newn;
	}
	stacksize++;

}

/* print list function */
void printList(struct node* n){
 	while(n != 0){
 		printf("%d ", n->num);
 		n = n->next;
 	}
 	printf("\n");
 }

void freeList(struct node* t){
	if(t == 0){
		return;
	}
	freeList(t->next);
	free(t);
	return;
}

/* compare strings */
int compare(char str1[], char str2[]){
	for(int i=0;str1[i]!='\0';i++){
    	if(str1[i]!=str2[i]){
        	return 0;
    	}
	}
	return 1;
}
