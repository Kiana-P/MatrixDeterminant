#include <stdio.h>
#include <stdlib.h>

struct node{
	int num;
	struct node* next;
};
typedef struct node node;


int compare(char[], char[]);
void printList(node*);
void insert(node**, int);
void delete(node**, int);
void freeList(node*);

int main(int argc, char* argv[argc+1]){

	if(argc != 2){
		printf("error\n");
		return EXIT_SUCCESS;
	}

	FILE *f = fopen(argv[1], "r");
	char str[10];
	int i;
	node* head = 0;

	while(fscanf(f, " %s %d", &str[0], &i) != EOF){
		char ins[7] = "INSERT";
		char del[7] = "DELETE";
		if(compare(str,ins) == 1){
			insert(&head, i);
			printList(head);
		}
		else if(compare(str, del) == 1){
			if(head != 0){
				delete(&head, i);
				if(head != 0){
				  printList(head);
				}
				else{
				  printf("EMPTY\n");
				}
			}
			else{
				printf("EMPTY\n");
			}
		}
		else{
			printf("error\n");
		}
	}

	freeList(head);

	fclose(f);
	
	return EXIT_SUCCESS;
}

/* insert function */
void insert(node** head, int n){

	node* newn = 0;
	node* curr = 0;
	newn = (node *)malloc(sizeof(node));
	newn->num = n;
	newn->next = 0;

	/* linked list is empty */
	if(*head == 0){
		*head = newn;
		return;
	}
	/* if new node needs to be inserted at front */
	else if((*head)->num>(newn->num)){
		newn->next = *head;
		*head = newn;
	}
	/* search for placement for new node */
	else{
		curr = *head;
		while((curr->next != 0) && ((curr->next->num) <= newn->num)){
			curr = curr->next;
		}
		if(newn->num == curr->num){
		  free(newn);
		  return;
		}
		else{
			newn->next = curr->next;
			curr->next = newn;
		}
	}
}	

/* delete function */
void delete(node** head, int n){
	node* curr = *head;
	node* prev = *head;

	if(curr != 0 && curr->num == n){
		*head = curr->next;
		free(curr);
		return;
	}
	while(curr != 0 && curr->num != n){
		prev = curr;
		curr = curr->next;
	}
	if(curr == 0){
	  return;
	}
	prev->next = curr->next;
	free(curr);
}

/* print list function */
void printList(struct node* n){
 	while(n != 0){
 		printf("%d ", n->num);
 		n = n->next;
 	}
 	printf("\n");
 }

/* free list function */
void freeList(struct node* t){
	if(t == 0) return;
	freeList(t->next);
	free(t);
	return;
}

/* compare strings */
int compare(char str1[], char str2[]){
	for(int i=0;str1[i]!='\0';i++){
    	if(str1[i]==str2[i]){
        	return 1;
    	}
    	else {
    		return 0;
    	}
	}
	return 0;
}
