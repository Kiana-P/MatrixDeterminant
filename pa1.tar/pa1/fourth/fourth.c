#include<stdio.h>
#include<stdlib.h>

int** make_m(int);
void print_m(int**, int);
void free_m(int**, int);

int main(int argc, char* argv[argc+1]){

	int s = atoi(argv[1]);

	if(s%2 == 0){
		printf("error\n");
		return EXIT_SUCCESS;
	}
	if(s == 1){
		printf("%d\n", s);
		return EXIT_SUCCESS;
	}

	int** mat = make_m(s);
	int count = 1;
	int i = 0;
	int j = s/2;

	/* fill matrix with values */
	while(count<=s*s){
		mat[i][j] = count;
        i--;
        j++;
 
        if (count%s == 0){ 
            i = i + 2; 
            --j; 
        }
        else {
            if (j == s) {
                j -= s;
            }
            else if (i<0){
                i += s;
            }
        }
        count++;
	}

	print_m(mat, s);
	free_m(mat, s);

	return EXIT_SUCCESS;
}

int** make_m (int s){

	/* allocating space for matrix */
	int **mat = malloc(s*sizeof(int*));
	for(int i=0; i<s; i++){
		mat[i] = malloc(s*sizeof(int));
	}

	/* read elements into matrix */
	for(int i=0; i<s; i++){
		for(int j=0; j<s; j++){
			mat[i][j] = 0;
		}
	}
	return mat;
}

void print_m(int** mat, int s){

	for(int i=0; i<s; i++){
		for(int j=0; j<s; j++){
		  printf("%d\t", mat[i][j]);
		}
		printf("\n");
	}

}

void free_m(int** mat, int s){
	for(int i=0; i<s; i++){
		free(mat[i]);
	}
	free(mat);
}
