#include <stdio.h>
#include <stdlib.h>

int isPrime (int);

int main(int argc, char* argv[argc+1]){

	if(argc != 2){
		printf("error\n");
		return EXIT_SUCCESS;
	}

	FILE* f = fopen(argv[1], "r");
	int i;

	while(fscanf(f, " %d", &i) != EOF){

		/* If number is prime check number+2 and number-2 */
		if (isPrime(i) == 1){
			if((isPrime(i+2) == 1) || (isPrime(i-2) == 1)){
				printf("yes\n");
			}
			else{
				printf("no\n");
			}
		}

		/* If number is not prime */
		else{
			printf("no\n");
		}
	}
	
	fclose(f);

	return EXIT_SUCCESS;
}

/* Function to check if numbers are prime */
int isPrime(int num){
	if (num <= 1){
		return 0;
	}
	for(int i = 2; i < num; i++){
		if(num % i == 0){
			return 0;
		}
	}
	return 1;
}

